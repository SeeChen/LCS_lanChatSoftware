#ifndef NOTEPADWINDOW_H
#define NOTEPADWINDOW_H

#include <QMainWindow>
#include <QMenuBar>
#include <QMenu>
#include <QAction>
#include <QTextEdit>
#include <QDebug>
#include <QMessageBox>
#include <QFileDialog>
#include <QInputDialog>
#include <QTextCodec>
#include <QTextBlock>
#include <QTextCursor>
#include <QString>

QT_BEGIN_NAMESPACE
namespace Ui { class notePadWindow; }
QT_END_NAMESPACE

class notePadWindow : public QMainWindow
{
    Q_OBJECT

public:
    notePadWindow(QWidget *parent = nullptr);
    ~notePadWindow();

    void newWindowTitle();

private:
    Ui::notePadWindow *ui;
    QTextEdit *textEdit;
    QString filePath = NULL;
    QFile *file;
    QFileInfo *info;
    QString fileName;
    QString findText;

    void setCursorToFront();

private slots:
    void onNewTriggered();
    void onSaveTriggered();
    void onSaveAsTriggered();
    void onOpenFileTriggered();
    void onNewWindowTriggered();
    void onExitTriggered();

    void onFindTriggered();
    bool onFindNextTriggered();

    void onTextChanged();

    void onAboutQtTriggered();

};
#endif // NOTEPADWINDOW_H
