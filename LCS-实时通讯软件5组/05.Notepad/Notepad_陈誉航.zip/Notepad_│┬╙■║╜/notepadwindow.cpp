#include "notepadwindow.h"
#include "ui_notepadwindow.h"

#include <QDebug>

notePadWindow::notePadWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::notePadWindow)
{
    ui->setupUi(this);

    this->setWindowTitle("Untitled - VI's Notepad");


    //MenuBar
    QMenuBar  *menuBar =  this->menuBar();

    QMenu *menuFile = menuBar->addMenu("文件");
    QMenu *menuEdit = menuBar->addMenu("编辑");
    QMenu *menuView = menuBar->addMenu("视图");
    QMenu *menuHelp = menuBar->addMenu("帮助");

    QAction *actionNew = menuFile->addAction("新建");
    QAction *actionNewWindow = menuFile->addAction("新建一个窗口");
    QAction *actionOpen = menuFile->addAction("打开文件");
    QAction *actionSave = menuFile->addAction("保存");
    QAction *actionSaveAs = menuFile->addAction("另存为");
    menuFile->addSeparator();
    QAction *actionExit = menuFile->addAction("离开");


    QAction *actionFind = menuEdit->addAction("查找");
    QAction *actionFindNext = menuEdit->addAction("查找下一个");
    menuEdit->addSeparator();
    QAction *actionReplace = menuEdit->addAction("替代");

    QAction *actionZoom = menuView->addAction("放大");
    QAction *actionZoomOut = menuView->addAction("缩小");

    QAction *actionAboutQt = menuHelp->addAction("关于Qt");

    //MainArea
    textEdit = new QTextEdit(this);
    this->setCentralWidget(textEdit);

    //文件操作
    connect(actionNew,&QAction::triggered,this,&notePadWindow::onNewTriggered);
    connect(actionSaveAs,&QAction::triggered,this,&notePadWindow::onSaveAsTriggered);
    connect(actionSave,&QAction::triggered,this,&notePadWindow::onSaveTriggered);
    connect(actionOpen,&QAction::triggered,this,&notePadWindow::onOpenFileTriggered);
    connect(actionNewWindow,&QAction::triggered,this,&notePadWindow::onNewWindowTriggered);
    connect(actionExit,&QAction::triggered,this,&notePadWindow::onExitTriggered);

    //功能操作
    connect(actionFind,&QAction::triggered,this,&notePadWindow::onFindTriggered);
    connect(actionFindNext,&QAction::triggered,this,&notePadWindow::onFindNextTriggered);
    connect(actionReplace,&QAction::triggered,
            [=](){
       QInputDialog *replaceDialog = new QInputDialog(this);
       QString replaceText = replaceDialog->getText(this,"请输入要替换的字符串",QString("%1替代为:").arg((findText)));
       setCursorToFront();
       if(replaceText == ""){
           return;
       }else{
           do{
               textEdit->cut();
               textEdit->insertPlainText(replaceText);
           }while(onFindNextTriggered());
       }
    });

    //更多功能操作
    connect(actionZoom,&QAction::triggered,
            [=](){
       textEdit->zoomIn(3);
    });
    connect(actionZoomOut,&QAction::triggered,
            [=](){
       textEdit->zoomOut(3);
    });

    //文本改变
    connect(textEdit,&QTextEdit::textChanged,this,&notePadWindow::onTextChanged);

    //帮助
    connect(actionAboutQt,&QAction::triggered,this,&notePadWindow::onAboutQtTriggered);



}

notePadWindow::~notePadWindow()
{
    delete ui;
}

void notePadWindow::newWindowTitle()
{
    QString str(QString("%1 - VI's Notepad").arg(fileName));
    this->setWindowTitle(str);
}

void notePadWindow::setCursorToFront()
{
    QTextCursor textCursor = textEdit->textCursor();
    textCursor.movePosition(QTextCursor::Start);
    textEdit->setTextCursor(textCursor);
}

void notePadWindow::onNewTriggered()
{

    QString txt = textEdit->toPlainText();

    if(txt == ""){

    }else{
        int value = QMessageBox::question(this,"记事本","是否要保存",QMessageBox::Yes,QMessageBox::No,QMessageBox::Cancel);

        switch(value){
            case(QMessageBox::Yes):
                onSaveAsTriggered();
                break;
            case(QMessageBox::No):
                textEdit->setText("");
                break;
            case(QMessageBox::Cancel):
                return;
                break;
        }

    }
}

void notePadWindow::onSaveTriggered()
{
    if(filePath == NULL){
        onSaveAsTriggered();
    }else{
        bool isOpen = file->open(QIODevice::WriteOnly);
        //测试是否链接
        if(isOpen){
            QTextCodec *codec = QTextCodec::codecForName("UTF8");
            QTextCodec::setCodecForLocale(codec);
            QString arr = textEdit->toPlainText();
            QByteArray arr1 = arr.toUtf8();
            file->write(arr1);
            qDebug()<<"File saved";
            newWindowTitle();
            file->close();
        }
    }
}

void notePadWindow::onSaveAsTriggered()
{
    //打开文件
    filePath = QFileDialog::getSaveFileName(this,tr("保存文件"), "./", tr("txt(*.txt)"));
    file = new QFile(filePath);
    info= new QFileInfo(filePath);
    fileName = info->fileName().toUtf8();

    bool isOpen = file->open(QIODevice::WriteOnly);
    //测试是否链接
    if(isOpen){
        newWindowTitle();
        QTextCodec *codec = QTextCodec::codecForName("UTF8");
        QTextCodec::setCodecForLocale(codec);
        QString arr = textEdit->toPlainText();
        QByteArray arr1 = arr.toUtf8();
        file->write(arr1);
        qDebug()<<"File saved";
        file->close();
    }

}

void notePadWindow::onOpenFileTriggered()
{
    filePath = QFileDialog::getOpenFileName(this,"Open file","./","txt(*.txt)");
    info= new QFileInfo(filePath);
    fileName = info->fileName().toUtf8();

    if(false == filePath.isEmpty()){
        file= new QFile(filePath);

        bool isOpen = file->open(QIODevice::ReadOnly);
        //如果打开成功，读取内容
        if(isOpen){
            newWindowTitle();
            QTextCodec *codec = QTextCodec::codecForName("UTF8");
            QTextCodec::setCodecForLocale(codec);
            QByteArray arr = file->readAll();
            textEdit->setText(arr);

            file->close();
        }
    }
}

void notePadWindow::onNewWindowTriggered()
{

}

void notePadWindow::onExitTriggered()
{
    onSaveTriggered();
    this->close();
}

void notePadWindow::onFindTriggered()
{
    //将换取第一个位置
    setCursorToFront();

    //弹出对话框获取要查找的字串
    QInputDialog *inDialog = new QInputDialog(this);
    findText = inDialog->getText(this,"请输入要查找的字符串","查找：");
    //查找QString里面包含的字
    textEdit->find(findText);
}

bool notePadWindow::onFindNextTriggered()
{
    return textEdit->find(findText);
}

void notePadWindow::onTextChanged()
{
    QString str(QString("*%1 - VI's Notepad").arg(fileName));
    this->setWindowTitle(str);
}

void notePadWindow::onAboutQtTriggered()
{
    QMessageBox::aboutQt(this,"关于Qt对话框");
}

