#include "notepadwidget.h"
#include "ui_notepadwidget.h"

notepadWidget::notepadWidget(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::notepadWidget)
{
    ui->setupUi(this);

    //New file
    ui->actionNew_file->setShortcut(QKeySequence(tr("ctrl+N")));
    connect(ui->actionNew_file,&QAction::triggered,this,[=](){
        ui->textEdit->clear();
    });

    //Open file
    ui->actionOpen_file->setShortcut(QKeySequence(tr("ctrl+O")));
    //ui->actionOpen_file->setShortcutVisibleInContextMenu(true);
    connect(ui->actionOpen_file,&QAction::triggered,this,[=](){
        QString oPath = QFileDialog::getOpenFileName(this,"Open file","../","txt(*.txt)");
        if(oPath.isEmpty() == false){
            QFile *oFile = new QFile(oPath);
            filePath = oFile->fileName();
            //QFileDialog::getSaveFileUrl();
            bool isOk = oFile->open(QIODevice::ReadOnly);

            if(true == isOk){
                QByteArray array = oFile->readAll();
                ui->textEdit->setText(array);
            }
            oFile->close();
            this->setWindowTitle(oFile->fileName());
        }
    });

    //Save
    ui->actionSave_as->setShortcut(QKeySequence(tr("ctrl+S")));
    connect(ui->actionSave_as,&QAction::triggered,this,[=](){
        QString sPath = QFileDialog::getSaveFileName(this,"Save","../","txt(*.txt)");
        if(sPath.isEmpty() == false){
            QFile *sFile = new QFile(this);
            sFile->setFileName(sPath);

            bool isOk = sFile->open(QIODevice::WriteOnly);
            if(isOk == true){
                QString str = ui->textEdit->toPlainText();
                sFile->write(str.toLocal8Bit());
            }
            sFile->close();
        }
    });

    //Exit
    connect(ui->actionExit,&QAction::triggered,this,[=](){
       this->close();
    });

    //Bold
    ui->actionBold->setShortcut(QKeySequence(tr("ctrl+B")));
    connect(ui->actionBold,&QAction::triggered,this,[=](){
        QString str ;
        textCursor = ui->textEdit->textCursor();

        if(textCursor.hasSelection()){
            font = textCursor.charFormat().font();
            if(!textCursor.charFormat().font().bold()){
                font.setBold(true);
                format.setFont(font);
                textCursor.setCharFormat(format);
            }
            else{
                font.setBold(false);
                format.setFont(font);
                textCursor.setCharFormat(format);
           }
           ui->textEdit->setTextCursor(textCursor);
        }
    });

    //Italic
    ui->actionItalic->setShortcut(QKeySequence(tr("ctrl+I")));
    connect(ui->actionItalic,&QAction::triggered,this,[=](){
        QString str ;
        textCursor = ui->textEdit->textCursor();

        if(textCursor.hasSelection()){
            font = textCursor.charFormat().font();
            if(!textCursor.charFormat().font().italic()){
                font.setItalic(true);
                format.setFont(font);
                textCursor.setCharFormat(format);
            }
            else{
                font.setItalic(false);
                format.setFont(font);
                textCursor.setCharFormat(format);
           }
           ui->textEdit->setTextCursor(textCursor);
        }
    });

    //Underline
    ui->actionUnderline->setShortcut(QKeySequence(tr("ctrl+U")));
    connect(ui->actionUnderline,&QAction::triggered,this,[=](){
        QString str ;
        textCursor = ui->textEdit->textCursor();

        if(textCursor.hasSelection()){
            font = textCursor.charFormat().font();
            if(!textCursor.charFormat().font().underline()){
                font.setUnderline(true);
                format.setFont(font);
                textCursor.setCharFormat(format);
            }
            else{
                font.setUnderline(false);
                format.setFont(font);
                textCursor.setCharFormat(format);
           }
           ui->textEdit->setTextCursor(textCursor);
        }
    });
}

notepadWidget::~notepadWidget()
{
    delete ui;
}


