#ifndef NOTEPADWIDGET_H
#define NOTEPADWIDGET_H

#include <QMainWindow>
#include <QKeySequence>
#include <QKeySequenceEdit>
#include <QString>
#include <QFile>
#include <QFileDialog>
#include <QDebug>
#include <QToolBar>
#include <QTextCursor>
#include <QFont>
#include <QTextCharFormat>
#include <QAction>

QT_BEGIN_NAMESPACE
namespace Ui { class notepadWidget; }
QT_END_NAMESPACE

class notepadWidget : public QMainWindow
{
    Q_OBJECT

public:
    notepadWidget(QWidget *parent = nullptr);
    ~notepadWidget();
    QString filePath = "";

private:
    Ui::notepadWidget *ui;
    QTextCursor textCursor;
    QFont font;
    QTextCharFormat format;
};
#endif // NOTEPADWIDGET_H
