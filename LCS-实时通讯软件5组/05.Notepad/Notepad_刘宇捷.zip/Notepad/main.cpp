#include "notepadwidget.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    notepadWidget w;
    w.setWindowTitle("1820201052 刘宇捷 notepad");
    w.show();
    return a.exec();
}
