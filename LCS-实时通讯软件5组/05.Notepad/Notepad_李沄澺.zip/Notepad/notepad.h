#ifndef NOTEPAD_H
#define NOTEPAD_H

#include <QMainWindow>
#include <QTextEdit>
#include <QAction>
#include <QLabel>

QT_BEGIN_NAMESPACE
namespace Ui { class notepad; }
QT_END_NAMESPACE

class notepad : public QMainWindow
{
    Q_OBJECT

public:
    notepad(QWidget *parent = nullptr);
    ~notepad();
    QTextEdit *textEdit;
    QString currentFile;
    QLabel *textInfo;

public slots:
    void newFileAct();
    void newWindowAct();
    void openFileAct();
    void saveFileAct();
    void saveAsFileAct();
    void closeFileAct();

    void undoAct();
    void redoAct();
    void cutAct();
    void copyAct();
    void pasteAct();
    void delAct();
    void selectAllAct();

    void zoomInAct();
    void zoomOutAct();

    void closeEvent(QCloseEvent *event);

    void changeFontFamily();

    void changeFontColor();

    void showTextInfo();

private:
    Ui::notepad *ui;
};
#endif // NOTEPAD_H
