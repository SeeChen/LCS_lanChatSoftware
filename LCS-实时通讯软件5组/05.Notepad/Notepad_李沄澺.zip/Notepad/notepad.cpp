#include "notepad.h"
#include "ui_notepad.h"
#include <QAction>
#include <QTextEdit>
#include <QFileDialog>
#include <QTextCodec>
#include <QDebug>
#include <QMessageBox>
#include <QCloseEvent>
#include <QToolBar>
#include <QDialog>
#include <QFontDialog>
#include <QColorDialog>
#include <QLabel>

notepad::notepad(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::notepad)
{
    ui->setupUi(this);
    this->setWindowTitle("Notepad");
    QFont v ("幼圆",10);
    this->setFont(v);

    //菜单栏
    QMenuBar *menubar = this->menuBar();

    //工具栏
    QToolBar *toolbar = new QToolBar;
    toolbar->setOrientation(Qt::Vertical);
    addToolBar(Qt::LeftToolBarArea,toolbar);

    textInfo = new QLabel();
    textInfo->setText("Start");
    statusBar()->addPermanentWidget(textInfo);

    //菜单
    QMenu *menuFile = menubar->addMenu("文件");
    QMenu *menuEdit = menubar->addMenu("编辑");
    QMenu *menuView = menubar->addMenu("查看");

    //菜单动作
    //文件区
    QAction *newFile = menuFile->addAction("新建");
    newFile->setFont(v);
    QAction *newWindow = menuFile->addAction("新建窗口");
    newWindow->setFont(v);
    QAction *divider1 = new QAction(this);
    divider1->setSeparator(true);
    menuFile->addAction(divider1);
    QAction *openFile = menuFile->addAction("打开");
    openFile->setFont(v);
    QAction *saveFile = menuFile->addAction("保存");
    saveFile->setFont(v);
    QAction *saveAsFile = menuFile->addAction("另存为");
    saveAsFile->setFont(v);
    QAction *divider2 = new QAction(this);
    divider2->setSeparator(true);
    menuFile->addAction(divider2);
    QAction *exit = menuFile->addAction("关闭");
    exit->setFont(v);
    //编辑区
    QAction *undo = menuEdit->addAction("撤回");
    undo->setFont(v);
    QAction *redo = menuEdit->addAction("复原");
    redo->setFont(v);
    QAction *divider3 = new QAction(this);
    divider3->setSeparator(true);
    menuEdit->addAction(divider3);
    QAction *cut = menuEdit->addAction("剪切");
    cut->setFont(v);
    QAction *copy = menuEdit->addAction("复制");
    copy->setFont(v);
    QAction *paste = menuEdit->addAction("粘贴");
    paste->setFont(v);
    QAction *del = menuEdit->addAction("删除");
    del->setFont(v);
    QAction *selectAll = menuEdit->addAction("全选");
    selectAll->setFont(v);
    //查看区
    QAction *zoomIn = menuView->addAction("放大");
    zoomIn->setFont(v);
    QAction *zoomOut = menuView->addAction("缩小");
    zoomOut->setFont(v);

    //添加工具栏
    QAction *toolOpen = toolbar->addAction(QIcon(":/image/openfile.png"),"打开");
    toolOpen->setStatusTip("打开");
    QAction *toolSave = toolbar->addAction(QIcon(":/image/save.png"),"保存");
    toolSave->setStatusTip("保存");
    QAction *divider4 = new QAction(this);
    divider4->setSeparator(true);
    toolbar->addAction(divider4);
    QAction *toolCopy = toolbar->addAction(QIcon(":/image/copy.png"),"复制");
    toolCopy->setStatusTip("复制");
    QAction *toolPaste = toolbar->addAction(QIcon(":/image/paste.png"),"粘贴");
    toolPaste->setStatusTip("粘贴");
    QAction *divider5 = new QAction(this);
    divider5->setSeparator(true);
    toolbar->addAction(divider5);
    QAction *toolZoomIn = toolbar->addAction(QIcon(":/image/zoomin.png"),"放大");
    toolZoomIn->setStatusTip("放大");
    QAction *toolZoomOut = toolbar->addAction(QIcon(":/image/zoomout.png"),"缩小");
    toolZoomOut->setStatusTip("缩小");
    QAction *divider6 = new QAction(this);
    divider6->setSeparator(true);
    toolbar->addAction(divider6);
    QAction *toolUndo = toolbar->addAction(QIcon(":/image/undo.png"),"撤回");
    toolZoomOut->setStatusTip("撤回");
    QAction *toolRedo = toolbar->addAction(QIcon(":/image/redo.png"),"复原");
    toolZoomOut->setStatusTip("复原");
    QAction *divider7 = new QAction(this);
    divider7->setSeparator(true);
    toolbar->addAction(divider7);
    QAction *toolFont = toolbar->addAction(QIcon(":/image/font.png"),"字体");
    toolFont->setStatusTip("字体");
    QAction *toolColor = toolbar->addAction(QIcon(":/image/color.png"),"颜色");
    toolColor->setStatusTip("颜色");

    //主工作区
    textEdit = new QTextEdit;
    this->setCentralWidget(textEdit);
    connect(textEdit,SIGNAL(cursorPositionChanged()),this,SLOT(showTextInfo()));

    //连接信号与槽
    //文件区
    connect(newFile,&QAction::triggered,this,&notepad::newFileAct);
    connect(newWindow,&QAction::triggered,this,&notepad::newWindowAct);
    connect(openFile,&QAction::triggered,this,&notepad::openFileAct);
    connect(saveFile,&QAction::triggered,this,&notepad::saveFileAct);
    connect(saveAsFile,&QAction::triggered,this,&notepad::saveAsFileAct);
    connect(exit,&QAction::triggered,this,&notepad::closeFileAct);
    //编辑区
    connect(undo,&QAction::triggered,this,&notepad::undoAct);
    connect(redo,&QAction::triggered,this,&notepad::redoAct);
    connect(cut,&QAction::triggered,this,&notepad::cutAct);
    connect(copy,&QAction::triggered,this,&notepad::copyAct);
    connect(paste,&QAction::triggered,this,&notepad::pasteAct);
    connect(del,&QAction::triggered,this,&notepad::delAct);
    connect(selectAll,&QAction::triggered,this,&notepad::selectAllAct);
    //查看区
    connect(zoomIn,&QAction::triggered,this,&notepad::zoomInAct);
    connect(zoomOut,&QAction::triggered,this,&notepad::zoomOutAct);
    //工具栏区
    connect(toolOpen,&QAction::triggered,this,&notepad::openFileAct);
    connect(toolSave,&QAction::triggered,this,&notepad::saveFileAct);
    connect(toolCopy,&QAction::triggered,this,&notepad::copyAct);
    connect(toolPaste,&QAction::triggered,this,&notepad::pasteAct);
    connect(toolZoomIn,&QAction::triggered,this,&notepad::zoomInAct);
    connect(toolZoomOut,&QAction::triggered,this,&notepad::zoomOutAct);
    connect(toolUndo,&QAction::triggered,this,&notepad::undoAct);
    connect(toolRedo,&QAction::triggered,this,&notepad::redoAct);
    connect(toolFont,&QAction::triggered,this,&notepad::changeFontFamily);
    connect(toolColor,&QAction::triggered,this,&notepad::changeFontColor);
}

notepad::~notepad()
{
    delete ui;
}

void notepad::newFileAct()
{
    if(!textEdit->toPlainText().isEmpty())
    {
        //弹出保存警告框
        int mes = QMessageBox::warning(this,"Warning","是否保存当前文件?",
                             QMessageBox::Save,QMessageBox::No,QMessageBox::Cancel);
        switch(mes)
        {
            case QMessageBox::Save:
                if(currentFile.isEmpty())
                {
                    saveAsFileAct();
                }
                else
                {
                    saveFileAct();
                }
                currentFile.clear();
                textEdit->setText(QString());
                this->setWindowTitle("Notepad");
            break;

            case QMessageBox::No:
                currentFile.clear();
                textEdit->setText(QString());
                this->setWindowTitle("Notepad");
            break;

            case QMessageBox::Cancel:
            break;
        }
    }
};

void notepad::newWindowAct()
{
    notepad *newwindow = new notepad;
    newwindow->show();
};

void notepad::openFileAct()
{
    QString path = QFileDialog::getOpenFileName(this,
                     "Open","../","txt(*.txt)");
    //判断是否成功获得文件的路径
    if(false == path.isEmpty())
    {
        QFile *file = new QFile(path);
        //打开文件
        bool isOk = file->open(QFile::ReadOnly);
        //如果打开成功，则读取内容
        if(true == isOk)
        {
            //读文件
            QTextCodec *codec = QTextCodec::codecForName("GBK");
            QByteArray array = file->readAll();
            //读完后显示到textedit
            textEdit->setText(codec->toUnicode(array));
        }
        currentFile = path;
        QFileInfo fileinfo(path);
        this->setWindowTitle(fileinfo.fileName());
        file->close();
    }
}

void notepad::saveFileAct()
{
    QString path;
    if(currentFile.isEmpty())
    {
        path = QFileDialog::getSaveFileName(this,"保存","../","txt(*.txt)");
        currentFile = path;
    }
    else
    {
        path = currentFile;
    }
    qDebug() << path << currentFile;
    QFile *file = new QFile();
    file->setFileName(path);
    bool isOk = file->open(QIODevice::WriteOnly);
    if(true == isOk){
        //获取编辑区内容
        QString str = textEdit->toPlainText();
        //写入文件
        file->write(str.toLocal8Bit());
    }
    QFileInfo fileinfo(path);
    this->setWindowTitle(fileinfo.fileName());
    file->close();
}

void notepad::saveAsFileAct()
{
    QString path = QFileDialog::getSaveFileName(this,
                     "另存为","../","txt(*.txt)");
    //判断路径是否存在，如果存在则保存
    if(false == path.isEmpty()){
        //创建文件对象
        QFile *file = new QFile();
        //文件对象关联硬盘文件路径
        file->setFileName(path);
        //打开文件，以只写方式
        bool isOk = file->open(QIODevice::WriteOnly);
        if(true == isOk){
            //获取编辑区内容
            QString str = textEdit->toPlainText();
            //写入文件
            file->write(str.toLocal8Bit());
        }
        currentFile = path;
        QFileInfo fileinfo(path);
        this->setWindowTitle(fileinfo.fileName());
        file->close();
    }
}

void notepad::closeFileAct()
{
    this->close();
}

void notepad::undoAct()
{
    textEdit->undo();
}

void notepad::redoAct()
{
    textEdit->redo();
}

void notepad::cutAct()
{
    textEdit->cut();
}

void notepad::copyAct()
{
    textEdit->copy();
}

void notepad::pasteAct()
{
    textEdit->paste();
}

void notepad::delAct()
{
    textEdit->textCursor().deletePreviousChar();
}

void notepad::selectAllAct()
{
    textEdit->selectAll();
}

void notepad::zoomInAct()
{
    textEdit->zoomIn();
}

void notepad::zoomOutAct()
{
    textEdit->zoomOut();
}

//关闭窗口前，若未保存会弹出窗口
void notepad::closeEvent(QCloseEvent *event)
{
    if(!textEdit->toPlainText().isEmpty())
    {
        //弹出保存警告框
        int mes = QMessageBox::warning(this,"Warning","是否保存当前文件?",
                             QMessageBox::Save,QMessageBox::No,QMessageBox::Cancel);
        switch(mes)
        {
            case QMessageBox::Save:
                if(currentFile.isEmpty())
                {
                    saveAsFileAct();
                }
                else
                {
                    saveFileAct();
                }
                currentFile.clear();
                event->accept();
            break;

            case QMessageBox::No:
                currentFile.clear();
                event->accept();
            break;

            case QMessageBox::Cancel:
                event->ignore();
            break;
        }
    }
}

void notepad::changeFontFamily()
{
    QFontDialog fontDlg;
    QFont font;
    bool isChanged;
    font = fontDlg.getFont(&isChanged);
    if(isChanged){
    textEdit->setFont(font);
    }
}

void notepad::changeFontColor()
{
    QColorDialog colorDlg;
    QColor color;
    QPalette palette = textEdit->palette();
    color = colorDlg.getColor(Qt::black);
    if (color.isValid())
    {
    palette.setColor(QPalette::Text, color);
    textEdit->setPalette(palette);
    }
}

//在Statusbar中显示当前行数和字数
void notepad::showTextInfo()
{
    QTextCursor textCursor = textEdit->textCursor();
    int lineNum = textCursor.blockNumber();
    int colNum = textCursor.columnNumber();
    textInfo->setText(tr("Line:%1,Word:%2").arg(lineNum+1).arg(colNum));
}

