#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QDebug>
#include <QMessageBox>
#include <QFile>
#include <QFileDialog>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //记事本标题名
    ui->textEdit->setDocumentTitle("Untitled - Notepad");
    //用户保存而更改记事本标题名
    setWindowTitle(ui->textEdit->documentTitle());

    //功能连接
    //文件（F）——菜单栏
    connect(ui->newFileAction,&QAction::triggered,this,&MainWindow::newFile);
    connect(ui->openFileAction,&QAction::triggered,this,&MainWindow::openFile);
    connect(ui->saveFileAction,&QAction::triggered,this,&MainWindow::save);
    connect(ui->saveAsFileAction,&QAction::triggered,this,&MainWindow::save_as);

    connect(ui->exitNotepadAction,&QAction::triggered,this,&MainWindow::exit);

    //编辑(E)——菜单栏
    connect(ui->undoAction,&QAction::triggered,ui->textEdit,&QTextEdit::undo);
    connect(ui->redoAction,&QAction::triggered,ui->textEdit,&QTextEdit::redo);

    connect(ui->cutAction,&QAction::triggered,ui->textEdit,&QTextEdit::cut);
    connect(ui->copyAction,&QAction::triggered,ui->textEdit,&QTextEdit::copy);
    connect(ui->pasteAction,&QAction::triggered,ui->textEdit,&QTextEdit::paste);
    connect(ui->deleteAction,&QAction::triggered,this,&MainWindow::del);

    connect(ui->selectAllAction,&QAction::triggered,ui->textEdit,&QTextEdit::selectAll);

}

MainWindow::~MainWindow()
{
    delete ui;
}

//新建文件
void MainWindow::newFile()
{
    if (ui->textEdit->document()->isModified()) //判断编辑文件是否改变
    {
        qDebug() << "document is modified";
        switch (requestSave())  //判断是否需要保存文件
        {
            case QMessageBox::Yes : //确认保存
                saveDocument();
                if (!currentFileName.isEmpty()) //判断文件名是否为空
                {
                    currentFileName.clear();
                }
                setDocument("Untitled - Notepad");
                ui->textEdit->document()->clear();
                break;
            case QMessageBox::No :  //不保存
                setDocument("Untitled - Notepad");
                ui->textEdit->document()->clear();
                break;
            case QMessageBox::Cancel :  //取消
                qDebug() << "取消";
                break;
            default:
                break;
        }
    }
    else
    {
        qDebug() << "document is not modified";
    }
}

//保存文件名
QString MainWindow::saveDocument()
{
    QString fileName;
    //判断当前文件是否为空
    //如果没有则保存新建的文件，否则保存当前开启的文件
    if (currentFileName.isEmpty())
    {
        fileName = QFileDialog::getSaveFileName(this, tr("保存文件"), QDir::currentPath(), tr("文本(*.txt)"));
    }
    else
    {
        fileName = currentFileName;
    }
    QFile file;
    QTextStream *output;
    file.setFileName(fileName);
    output = new QTextStream(&file);
    if (file.open(QIODevice::WriteOnly))
    {
        //文件写入
        *output << ui->textEdit->document()->toPlainText();
        file.close();
    }
    return fileName;
}

//请求保存
int MainWindow::requestSave()
{
    int answer = QMessageBox::question(this, tr("notepad"),
                                        tr("是否将更改保存？"),
                                        QMessageBox::Yes | QMessageBox::No | QMessageBox::Cancel);
    return answer;
}

//设置文件名
void MainWindow::setDocument(QString title)
{
    ui->textEdit->setDocumentTitle(title);
    setWindowTitle(ui->textEdit->documentTitle());
}


//打开文件
void MainWindow::openFile()
{
    QString fileName = QFileDialog::getOpenFileName(this,tr("打开文件"));
    if (ui->textEdit->document()->isModified()) //编辑区内容是否改变
    {
        saveDocument();
    }
    openDocument();
    setDocument(currentFileName);
}

//获取文件函数
void MainWindow::openDocument()
{
    QString fileName;
    QFile file;
    QTextStream *in;

    fileName = QFileDialog::getOpenFileName(this, tr("打开文件"), QDir::currentPath(), tr("文本(*.txt)"));
    currentFileName = fileName;
    file.setFileName(fileName);
    in = new QTextStream(&file);
    if (file.open(QIODevice::ReadOnly))   //只写模式打开
    {
        ui->textEdit->setText(in->readAll());
        file.close();
    }
}

//保存文件
void MainWindow::save()
{
    if (ui->textEdit->document()->isModified() || !currentFileName.isEmpty())
    {
        QString tmpFileName = saveDocument();
        setDocument(tmpFileName);
        currentFileName = tmpFileName;
    }
}

//另存文件
void MainWindow::save_as()
{
    if (ui->textEdit->document()->isModified())
    {
        QString tmpFileName = currentFileName;
        currentFileName.clear();
        saveDocument();
        currentFileName = tmpFileName;
    }
}

void MainWindow::del()
{
    QTextCursor cursor=ui->textEdit->textCursor();//得到当前text的光标
    if(cursor.hasSelection())//如果有选中，则取消，以免受受影响
    cursor.clearSelection();
    cursor.deletePreviousChar();//删除前一个字符
    ui->textEdit->setTextCursor(cursor);//让光标移到删除后的位置
}

//退出
void MainWindow::exit()
{
    if (ui->textEdit->document()->isModified())
    {
        switch (requestSave())
        {
            case QMessageBox::Yes :
                saveDocument();
                this->close();
                break;
            case QMessageBox::No :
                this->close();
                break;
            case QMessageBox::Cancel :
                qDebug() << "取消";
                break;
            default:
                break;
        }
    }
}

